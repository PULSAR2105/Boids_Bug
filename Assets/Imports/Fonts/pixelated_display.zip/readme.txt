NOTE: Pixelated Display is for PERSONAL USE ONLY!
Please contact me before any commercial use.
My fonts for free use are allowed only in personal projects, and non-profit.
If you make money from using my fonts, Please purchase a commercial license.
Contact me at foundry@jetsmax.com
If you want DONATE click here http://www.paypal.me/KhairilAnwar
I really appreciate your donations.
Thank you 

Link to purchase full version and commercial license :
https://jetsmax.com/pixelated-display/

Please visit our store for more great fonts:
https://jetsmax.com
